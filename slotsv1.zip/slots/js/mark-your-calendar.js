(function($) {
    Date.prototype.addDays = function(days) {
        let date = new Date(this.valueOf());
        date.setDate(date.getDate() + days);
        return date;
    };
    $.fn.markyourcalendar = function(opts) {
        let defaults = {
            slots: {},
            availability: [[], [], [], [], [], [], []], // list of times to choose from
            isMultiple: false,
            months: ['jan', 'feb', 'mar', 'apr', 'may', 'jun', 'jul', 'aug', 'sep', 'oct', 'nov', 'dec'],
            selectedDates: [],
            startDate: new Date(),
            weekdays: ['sun', 'mon', 'tue', 'wed', 'thurs', 'fri', 'sat'],
        };
        let settings = $.extend({}, defaults, opts);

        let onClick = settings.onClick;
        let instance = this;
        let time = settings.slots['parayanaTime'];
        
        let date = new Date(time);
        console.log(date.toString());

        
        this.getMonthName = function(idx) {
            return settings.months[idx];
        };

        let formatDate = function(d) {
            let date = '' + d.getDate();
            let month = '' + (d.getMonth() + 1);
            let year = d.getFullYear();
            if (date.length < 2) {
                date = '0' + date;
            }
            if (month.length < 2) {
                month = '0' + month;
            }
            return year + '-' + month + '-' + date;
        };

        this.getNavControl = function() {
            let monthYearHtml = `
                <div id="myc-current-month-year-container">
                    ` + this.getMonthName(settings.startDate.getMonth()) + ' ' + settings.startDate.getFullYear() + `
                </div>
            `;

            let navHtml = `
                <div id="myc-nav-container">
                    ` + monthYearHtml + `
                </div>
            `;
            return navHtml;
        };

        // show the days
        this.getDatesHeader = function() {
            let tmp = ``;
            for (let i = 0; i < 7; i++) {
                let d = settings.startDate.addDays(i);
                tmp += `
                    <div class="myc-date-header" id="myc-date-header-` + i + `">
                        <div class="myc-date-number">` + d.getDate() + `</div>
                        <div class="myc-date-display">` + settings.weekdays[d.getDay()] + `</div>
                    </div>
                `;
            }
            let ret = `<div id="myc-dates-container">` + tmp + `</div>`;
            return ret;
        }

        // take the possible hours each day of the current week
        this.getAvailableTimes = function() {
            let tmp = ``;
            for (let i = 0; i < 7; i++) {
                let tmpAvailTimes = ``;
				console.log('test');
                console.log(settings.availability);
                $.each(settings.availability[i].slots, function() {
					
					// DEVELOPER: IF ELSE CONDITION TO CONTROL TOOLTIP
					if(!this.available) {
						
						tmpAvailTimes += `
                        <a href="javascript:;" class="tooltipped myc-available-time-`+this.available+`" data-time="` + this.time + `" data-date="` + formatDate(settings.startDate.addDays(i)) + ` " data-toggle="tooltip" data-placement="top" title="`+ this.bookedBy + `">
                            ` + this.time + `
                        </a>
                    `;
					} else {
						tmpAvailTimes += `
                        <a href="javascript:;" class="tooltipped myc-available-time-`+this.available+`" data-time="` + this.time + `" data-date="` + formatDate(settings.startDate.addDays(i)) + ` " data-toggle="tooltip" data-placement="top" title="Available">
                            ` + this.time + `
                        </a>
                    `;
					}
                    
                });
                tmp += `
                    <div class="myc-day-time-container" id="myc-day-time-container-` + i + `">
                        ` + tmpAvailTimes + `
                        <div style="clear:both;"></div>
                    </div>
                `;
            }
            return tmp
        }

        this.setAvailability = function(arr) {
            settings.availability = arr;
            render();
        }
        
        this.on('click', '.myc-available-time-true', function() {
            let date = $(this).data('date');
            let time = $(this).data('time');
            let tmp = date + ' ' + time;
            if ($(this).hasClass('selected')) {
                $(this).removeClass('selected');
                let idx = settings.selectedDates.indexOf(tmp);
                if (idx !== -1) {
                    settings.selectedDates.splice(idx, 1);
                }
            } else {
                if (settings.isMultiple) {
                    $(this).addClass('selected');
                    settings.selectedDates.push(tmp);
                } else {
                    settings.selectedDates.pop();
                    if (!settings.selectedDates.length) {
                        $('.myc-available-time-true').removeClass('selected');
                        $(this).addClass('selected');
                        settings.selectedDates.push(tmp);
                    }
                }
            }
            if ($.isFunction(onClick)) {
                onClick.call(this, ...arguments, settings.selectedDates);
            }
        });

        let render = function() {
            ret = `
                <div id="myc-container">
                    <div id="myc-nav-container">` + instance.getNavControl() + `</div>
                    <div id="myc-week-container">
                        <div id="myc-dates-container">` + instance.getDatesHeader() + `</div>
                        <div id="myc-available-time-container">` + instance.getAvailableTimes() + `</div>
                    </div>
                </div>
            `;
            instance.html(ret);
        };
        render();
    };
})(jQuery);
